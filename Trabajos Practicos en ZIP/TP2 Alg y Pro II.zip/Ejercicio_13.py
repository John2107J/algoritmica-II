import turtle


def koch(longitud, nivel):

    t = turtle.Turtle()
    t.speed(0)
            

    if nivel == 0: # Si el nivel es 0 se dibuja una recta
        t.forward(longitud)
    else:
        koch(longitud / 3, nivel - 1)
        t.left(60)

        koch(longitud / 3, nivel - 1)
        t.right(120)

        koch(longitud / 3, nivel - 1)
        t.left(60)

        koch(longitud / 3, nivel - 1)


if __name__ == "__main__":
    t = turtle.Turtle()
    t.speed(0)


    koch(200, 2) 
    turtle.mainloop()
